<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use Session;
if (!isset($_SESSION)) {
    session_start();
}
class VideoController extends Controller
{
    
    public function insertVideo(Request $request){
    	$data = array();
        $data['videoName'] = $request->videoName;
        $video = $request->file('video');
        $ext = strtolower($video->getClientOriginalExtension());
        $video_name = str_random(20);
        $video_full_name = $video_name . '.' . $ext;
        $upload_path = 'video/vid/';
        $video_url = $upload_path . $video_full_name;
        $success = $video->move($upload_path, $video_full_name);
        if ($success) {
            $data['video'] = $video_url;
            $insertVideoInfo = DB::table('video')
                                   ->insert($data);
            if ($insertVideoInfo) {
	        	return $this->returnJson("success", 'insertVideoInfo', $insertVideoInfo);
	        }else{
	        	return $this->returnJson("failed", 'insertVideoInfo', null);
	        }
        }
    }

    public function updateVideo(Request $request){
    	$videoId = $request->videoId;
    	$data = array();
        $data['videoName'] = $request->videoName;
        $video = $request->file('video');
        $ext = strtolower($video->getClientOriginalExtension());
        $video_name = str_random(20);
        $video_full_name = $video_name . '.' . $ext;
        $upload_path = 'video/vid/';
        $video_url = $upload_path . $video_full_name;
        $success = $video->move($upload_path, $video_full_name);
        if ($success) {
            $data['video'] = $video_url;
            $updateVideoInfo = DB::table('video')
                                   ->where('id', $videoId)
                                   ->update($data)
            if ($updateVideoInfo) {
	        	return $this->returnJson("success", 'updateVideoInfo', $updateVideoInfo);
	        }else{
	        	return $this->returnJson("failed", 'updateVideoInfo', null);
	        }
        }
    }

//all video show start here..
    public function showAllVideo(){
        $allVideoInfo = DB::table('video')
                           ->orderBy('id', 'DESC')
                           ->get();
        
        if ($allVideoInfo) {
                return $this->returnJson("success", 'allVideoInfo', $allVideoInfo);
            }else{
                return $this->returnJson("failed", 'allVideoInfo', null);
            }
    }
//all video show end here..


//delete indivisual video start here..
    public function deleteVideo($id){
        $deleteVideo=DB::table('video')
                        ->where('id',$id)
                        ->delete();
        if ($deleteVideo) {
                return $this->returnJson("success", 'deleteVideo', null);
            }else{
                return $this->returnJson("failed", 'deleteVideo', null);
            }
    }
//delete indivisual video end here..

//search video
    public function serachVideo(Request $request){

        $search=$request->searchText;

         $videoInfo=DB::table('video as vid')
                    ->join('video_like as vidL', 'vidL.videoId', 'vid.id')
                    ->join('video_comment as vidC', 'vidC.videoId', 'vid.id')
                    ->Where('vid.videoName', 'like', '%' .$search. '%')
                    ->Where('vidL.countLike', 'like', '%' .$search. '%')
                    ->Where('vidC.countComment', 'like', '%' .$search. '%')
                    ->Where('vidC.comment', 'like', '%' .$search. '%')
                    ->select('vid.*','vidL.*','vidC.*')
                    ->orderBy('vid.videoName','ASC')
                    ->limit(10)
                    ->get();

         
        return response()->json($videoInfo);
       
    }

//Total Like Count
    public function totalLike($videoId,$userId){
        $totalVideoLike=DB::table('video as vid')
                            ->join('video_like as vidL', 'vidL.videoId', 'vid.id')
                            ->where('vidL.videoId', $videoId)
                            ->where('vidL.userId', $userId)
                            ->count();

        if ($totalVideoLike) {
                return $this->returnJson("success", 'totalVideoLike', '$totalVideoLike');
            }else{
                return $this->returnJson("failed", 'totalVideoLike', null);
            }
    }

//Total comment Count
    public function totalComment($videoId,$userId){
        $totalVideoComment=DB::table('video as vid')
	                            ->join('video_comment as vidC', 'vidC.videoId', 'vid.id')
	                            ->where('vidC.videoId', $videoId)
	                            ->where('vidC.userId', $userId)
	                            ->count();

        if ($totalVideoComment) {
                return $this->returnJson("success", 'totalVideoComment', '$totalVideoComment');
            }else{
                return $this->returnJson("failed", 'totalVideoComment', null);
            }
    }

    private function returnJson($status, $objname, $data)
    {
        $info = array(
            'status' => $status,
            $objname => $data
        );
        return response()->json($info);
    }
}
