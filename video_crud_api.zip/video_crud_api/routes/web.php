<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::prefix('video')->group(function () {

	Route::post('insert-video', 'VideoController@insertVideo')->name('insertVideo');    // insert video
	Route::post('update-video', 'VideoController@updateVideo')->name('updateVideo');    // insert video
    Route::post('delete-video/{id}', 'VideoController@deleteVideo')->name('deleteVideo');//delete video
    Route::get('show-all-video', 'VideoController@showAllVideo')->name('showAllVideo');  // All video 
    Route::post('search-video', 'VideoController@serachVideo')->name('serachVideo');

    Route::post('total-like/{videoId}/{userId}', 'VideoController@totalLike')->name('totalLike');//Total Like Count
    Route::post('total-comment/{videoId}/{userId}', 'VideoController@totalComment')->name('totalComment');//Total Comment Count




});